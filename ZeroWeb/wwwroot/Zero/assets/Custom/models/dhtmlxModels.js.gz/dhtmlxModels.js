﻿class DhtmlxTable {
    static get btnAdd() { return "btnAdd"; }
    static get btnEdit() { return "btnEdit"; }
    static get btnSave() { return "btnSave"; }
    static get btnUpdate() { return "btnUpdate"; }
}
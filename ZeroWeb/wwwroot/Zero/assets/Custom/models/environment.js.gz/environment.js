﻿class Environment {
    static get basePath() { return environment.basePath; }
    static get isProduction() { return environment.isProduction; }
    static get isMultipleLanguages() { return environment.isMultipleLanguages; }
}